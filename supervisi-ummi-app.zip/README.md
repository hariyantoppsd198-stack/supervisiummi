# Form Supervisi Pembelajaran Al-Qur'an — Metode Ummi

Aplikasi web sederhana untuk melakukan supervisi pembelajaran Al‑Qur'an (metode Ummi) dan mengunduh rekap hasilnya ke **Excel**.  
**Dibuat oleh: Risyal Hariyanto**.

## Fitur
- Input identitas (sekolah, pengajar, kelas, program/jilid, sesi, jumlah murid, tanggal, supervisi ke-).  
- Penilaian 3 aspek seperti pada form:
  - A. Persiapan Mengajar (x1)
  - B. Penampilan (x3)
  - C. Penilaian Proses/Hasil Akhir (x2)
- Otomatis menghitung **Total A/B/C**, **Nilai Akhir (skala 4)**, dan **Predikat**.
- Catatan: **Kekuatan, Kelemahan, Saran**.
- Simpan banyak entri ke **Rekap Supervisi**.
- **Download Rekap (Excel)** menggunakan SheetJS (tanpa backend).
- Tampilan modern, mobile-friendly, dark theme.
- Atribusi jelas: *Aplikasi ini dibuat oleh Risyal Hariyanto*.

## Cara Pakai (Lokal)
1. Unduh repositori ini (atau klik tombol **Download ZIP** di GitHub).
2. Ekstrak, lalu buka `index.html` langsung di browser modern (Chrome/Edge/Firefox).
3. Isi form, klik **Hitung Nilai**, **Simpan ke Rekap**, lalu **Download Rekap (Excel)**.

> Tidak perlu Node.js atau server. Semua berjalan di sisi klien (browser).

## Deploy ke GitHub Pages
1. Buat repository baru di GitHub, mis. `supervisi-ummi-app`.
2. Upload berkas: `index.html`, `style.css`, `app.js`, `README.md`.
3. Di repo GitHub, buka **Settings → Pages**.
4. Pada **Build and deployment**, pilih `Deploy from a branch`, **Branch**: `main`, **Folder**: `/root`.
5. Simpan. URL GitHub Pages akan tampil dan siap dibagikan.

## Struktur Penilaian
Skor per butir **1–4**. Bobot: A×1, B×3, C×2.  
Nilai akhir mengikuti rentang di form:
- **3,55 – 4,00** = *Sangat Baik*
- **2,55 – 3,50** = *Baik*
- **2,05 – 2,50** = *Kurang*
- **1,00 – 2,00** = *Sangat Kurang*

> Implementasi: menjumlah skor A/B/C, lalu hitung nilai berbobot dan dinormalisasi ke skala 4.

## Lisensi
MIT — silakan modifikasi sesuai kebutuhan lembaga Anda.

---

© 2025 — Aplikasi ini dibuat oleh **Risyal Hariyanto**.
