/* Global state */
const records = [];

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));

function clampScore(v){
  const n = Number(v||0);
  if(isNaN(n)) return 0;
  return Math.min(4, Math.max(0, n));
}

function calcTotals(){
  const sum = (arr) => arr.reduce((a,b) => a + clampScore(b.value), 0);

  const totalA = sum($$('.score.a'));
  const totalB = sum($$('.score.b'));
  const totalC = sum($$('.score.c'));

  $('#totalA').value = totalA;
  $('#totalA').textContent = totalA;

  $('#totalB').value = totalB;
  $('#totalB').textContent = totalB;

  $('#totalC').value = totalC;
  $('#totalC').textContent = totalC;

  // Weighted final value as in the sheet: A x1, B x3, C x2; normalize to 30 like the image
  // Max A=8, B=24, C=20 -> Weighted = A*1 + B*3 + C*2; To scale to 30, divide by max weighted (8*1 + 24*3 + 20*2 = 8 + 72 + 40 = 120) then * 30
  const weighted = (totalA*1) + (totalB*3) + (totalC*2);
  const nilai30 = (weighted / 120) * 30;
  const nilai4 = nilai30 / 30 * 4; // convert to 4-scale as common rubric

  const predikat = (v) => {
    if(v >= 3.55) return 'Sangat Baik';
    if(v >= 2.55) return 'Baik';
    if(v >= 2.05) return 'Kurang';
    return 'Sangat Kurang';
  };

  $('#nilaiAkhir').textContent = nilai4.toFixed(2);
  $('#predikat').textContent = predikat(nilai4);

  return { totalA, totalB, totalC, nilai4, nilai30, weighted };
}

function readForm(){
  const ident = {
    tanggal: $('#tanggal').value,
    supervisiKe: $('#supervisiKe').value,
    namaSekolah: $('#namaSekolah').value,
    programJilid: $('#programJilid').value,
    namaUst: $('#namaUst').value,
    kelasTempat: $('#kelasTempat').value,
    sesiJam: $('#sesiJam').value,
    jumlahMurid: $('#jumlahMurid').value
  };

  const totals = calcTotals();

  const notes = {
    kekuatan: $('#kekuatan').value,
    kelemahan: $('#kelemahan').value,
    saran: $('#saran').value
  };

  const kets = {};
  $$('.ket').forEach(k => kets[k.dataset.key] = k.value);

  return { ident, totals, notes, kets, timestamp: new Date().toISOString() };
}

function addRecord(){
  const rec = readForm();
  records.push(rec);
  renderRekap();
}

function renderRekap(){
  const tbody = $('#rekapTbl tbody');
  tbody.innerHTML = '';
  for(const r of records){
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${r.ident.tanggal||''}</td>
      <td>${r.ident.supervisiKe||''}</td>
      <td>${r.ident.namaSekolah||''}</td>
      <td>${r.ident.namaUst||''}</td>
      <td>${r.ident.kelasTempat||''}</td>
      <td>${r.ident.programJilid||''}</td>
      <td>${r.ident.jumlahMurid||''}</td>
      <td>${r.totals.totalA}</td>
      <td>${r.totals.totalB}</td>
      <td>${r.totals.totalC}</td>
      <td>${r.totals.nilai4.toFixed(2)}</td>
      <td>${(function(){
        const v=r.totals.nilai4;
        if(v>=3.55) return 'Sangat Baik';
        if(v>=2.55) return 'Baik';
        if(v>=2.05) return 'Kurang';
        return 'Sangat Kurang';
      })()}</td>
    `;
    tbody.appendChild(tr);
  }
}

function exportExcel(){
  // Flatten records for Excel
  const rows = records.map((r, idx) => ({
    No: idx+1,
    Tanggal: r.ident.tanggal,
    'Supervisi Ke': r.ident.supervisiKe,
    'Nama Sekolah': r.ident.namaSekolah,
    'Ust/Us': r.ident.namaUst,
    'Kelas/Tempat': r.ident.kelasTempat,
    'Program/Jilid': r.ident.programJilid,
    'Jumlah Murid': r.ident.jumlahMurid,
    'Total A': r.totals.totalA,
    'Total B': r.totals.totalB,
    'Total C': r.totals.totalC,
    'Nilai Akhir (Skala 4)': r.totals.nilai4.toFixed(2),
    'Predikat': (function(){
      const v=r.totals.nilai4;
      if(v>=3.55) return 'Sangat Baik';
      if(v>=2.55) return 'Baik';
      if(v>=2.05) return 'Kurang';
      return 'Sangat Kurang';
    })(),
    'Kekuatan': r.notes.kekuatan,
    'Kelemahan': r.notes.kelemahan,
    'Saran': r.notes.saran,
    'Dibuat oleh': 'Risyal Hariyanto'
  }));

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.json_to_sheet(rows);
  XLSX.utils.book_append_sheet(wb, ws, 'Rekap Supervisi');
  XLSX.writeFile(wb, 'rekap-supervisi-ummi.xlsx');
}

function resetForm(){
  document.querySelectorAll('input[type=text], input[type=number], textarea').forEach(i => i.value='');
  document.querySelectorAll('input[type=number].score').forEach(i => i.value='0');
  $('#nilaiAkhir').textContent = '0';
  $('#predikat').textContent = '-';
  calcTotals();
}

function init(){
  $('#year').textContent = new Date().getFullYear();
  calcTotals();

  $$('.score').forEach(i => i.addEventListener('input', calcTotals));
  $('#btnHitung').addEventListener('click', calcTotals);
  $('#btnSimpan').addEventListener('click', () => {
    addRecord();
    alert('Tersimpan ke rekap.');
  });
  $('#btnExport').addEventListener('click', () => {
    if(records.length === 0){
      if(!confirm('Rekap masih kosong. Ekspor form aktif saja?')){
        return;
      }
      addRecord();
    }
    exportExcel();
  });
  $('#btnReset').addEventListener('click', resetForm);
}

document.addEventListener('DOMContentLoaded', init);
